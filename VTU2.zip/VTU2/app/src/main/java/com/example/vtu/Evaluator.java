package com.example.vtu;

import com.fathzer.soft.javaluator.DoubleEvaluator;

class Evaluator extends DoubleEvaluator {
}
